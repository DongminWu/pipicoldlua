require 'luaunit'

require 'Oop.Tests.TestObject'
require 'Oop.Tests.TestObjectImplementation'
require 'Oop.Tests.TestPrototype'
--require 'Oop.Tests.TestTraits'

LuaUnit:run()
