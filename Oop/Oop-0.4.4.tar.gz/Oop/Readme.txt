'''Object.lua, a table for OOP.'''

This is a small project I've been working on to explore object-oriented programming (OOP) from the implementation perspective. Its goal is to provide Lua with minimal and reusable OOP, as well as to be easily predictable and extensible. --SebastienRoccaSerra

This is an early release, please report bugs & feature requests to my [http://sroccaserra.uservoice.com/ UserVoice page].

See also ObjectOrientedProgramming for other OOP libraries in Lua.


=== Features ===

        * Class oriented
        * All classes derive from Object
        * Single inheritance (with Traits coming soon!)
        * All method calls are virtual, the class of the instance determines the bound method
        * Access to superclass method in overriden methods with a Java-like {{super(self)}} method
        * The use of super only grants access to methods, NOT to data members (prevents many evils)
        * Consistent use of {{:}}, always use {{:}} to call any method of any class or instance
        * Object model allows to redefine {{new()}} in any class (see tests)
        * Hopefully only one way to do things, very predictible results

Note: there is a {{Prototype.lua}} file in the package, which is completely independant, but if you need prototype-based oop have a look at it (it provides a {{super(self)}} function).


=== Warnings ===

        * This is an early release.  Changes can be made in the future
        * No optimization.  This is still in the design stage


=== Code ===

This project's code can be dowloaded from its [http://luaforge.net/projects/objectlua/ LuaForge page]. See all releases [http://luaforge.net/frs/?group_id=416 here].


=== Tests and Usage ===

See TestObject.

The tests documenting {{Object.lua}} usage can be found in the {{Tests}} directory.

They use [http://luaforge.net/projects/luaunit/ LuaUnit].


=== References ===

        * [http://www.lua.org/pil/ PIL], by Roberto Ierusalimschy.
        * The [http://lua-users.org/wiki/ Lua Wiki].
        * [http://www.vpri.org/pdf/tr2006003a_objmod.pdf Open Reusable Object Models], by Ian Piumarta & Alessandro Warth, for bootstraping the object model.
        * [http://ejohn.org/blog/simple-javascript-inheritance/ This article] by John Resig for one of the previous implementations of super().
        * [http://mail.python.org/pipermail/python-dev/2001-May/014508.html This exchange] between Guido van Rossum (Python) and Jim Althoff (Smalltalk) for the object model.
        * [http://www.iam.unibe.ch/~scg/Archive/Papers/Scha03aTraits.pdf Traits: Composable Units of Behavior] by Nathanael Schärli, Stéphane Ducasse, Oscar Nierstrasz and Andrew Black for Traits

The main point is to bootstrap the object model and then,
build on it to populate {{Class}} with {{new()}}, {{inheritsFrom()}}, {{subclass()}},
and {{Object}} with {{initialize()}}, {{isKindOf()}}, {{clone()}}...

Thanks to Ludovic Perrine for making things clearer with enlightening discussions.
Thanks to Robert Rangel for finding a blocker bug fixed in version 0.0.3.

=== See Also ===

        * ObjectOrientedProgramming
        * The project's [http://luaforge.net/projects/objectlua/ LuaForge page]
        * My [http://sroccaserra.uservoice.com/ UserVoice page] for bugs & feature requests.
